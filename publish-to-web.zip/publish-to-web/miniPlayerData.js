klynt.miniPlayerData = {
    "downloadAppWording": "Download App",
    "thanksForWatchingWording": "Thanks for watching!",
    "title": "Canada 150",
    "resumePlaybackWording": "Resume playback?",
    "description": "",
    "yesWording": "Yes",
    "redirectToMobileApp": "never",
    "launchAppWording": "Then Launch Project",
    "analyticsKey": "",
    "url": "",
    "noWording": "No",
    "fullscreenInfoWording": "This program will launch in fullscreen",
    "thumbnail": "Medias/Photos/150.jpg"
}